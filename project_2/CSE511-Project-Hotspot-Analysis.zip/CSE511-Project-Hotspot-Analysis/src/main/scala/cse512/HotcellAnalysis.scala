package cse512

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions._

object HotcellAnalysis {
  Logger.getLogger("org.spark_project").setLevel(Level.WARN)
  Logger.getLogger("org.apache").setLevel(Level.WARN)
  Logger.getLogger("akka").setLevel(Level.WARN)
  Logger.getLogger("com").setLevel(Level.WARN)

  def runHotcellAnalysis(spark: SparkSession, pointPath: String): DataFrame =
  {
    // Load the original data from a data source
    var pickupInfo = spark.read.format("com.databricks.spark.csv").option("delimiter",";").option("header","false").load(pointPath);
    pickupInfo.createOrReplaceTempView("nyctaxitrips")
    pickupInfo.show(10)

    // Assign cell coordinates based on pickup points
    spark.udf.register("CalculateX",(pickupPoint: String)=>((
      HotcellUtils.CalculateCoordinate(pickupPoint, 0)
      )))
    spark.udf.register("CalculateY",(pickupPoint: String)=>((
      HotcellUtils.CalculateCoordinate(pickupPoint, 1)
      )))
    spark.udf.register("CalculateZ",(pickupTime: String)=>((
      HotcellUtils.CalculateCoordinate(pickupTime, 2)
      )))
    pickupInfo = spark.sql("select CalculateX(nyctaxitrips._c5),CalculateY(nyctaxitrips._c5), CalculateZ(nyctaxitrips._c1) from nyctaxitrips")
    var newCoordinateName = Seq("x", "y", "z")
    pickupInfo = pickupInfo.toDF(newCoordinateName:_*)
    pickupInfo.show(10)

    // Define the min and max of x, y, z
    val minX = -74.50/HotcellUtils.coordinateStep
    val maxX = -73.70/HotcellUtils.coordinateStep
    val minY = 40.50/HotcellUtils.coordinateStep
    val maxY = 40.90/HotcellUtils.coordinateStep
    val minZ = 1
    val maxZ = 31
    val numCells = (maxX - minX + 1)*(maxY - minY + 1)*(maxZ - minZ + 1)





    // After creating pickupInfo DataFrame and setting up min/max values
    // We need 
    // pickup in each cell
    // mean, std
    // spatial weight matrix



    // Create view for pickupInfo
    pickupInfo.createOrReplaceTempView("pickupinfo")


    // Calculate points in each cell
    val pointCounts = spark.sql(
      s"""
      SELECT x, y, z, COUNT(*) as count
      FROM pickupinfo
      WHERE x BETWEEN $minX AND $maxX
        AND y BETWEEN $minY AND $maxY
        AND z BETWEEN $minZ AND $maxZ
      GROUP BY x, y, z
      """)
    pointCounts.createOrReplaceTempView("pointcounts")
    pointCounts.show(10)



    // Calculate  mean, std
    val globalStats = spark.sql(
      """
      SELECT AVG(count) as mean,
             STDDEV(count) as std,
             COUNT(*) as num_cells
      FROM pointcounts
      """).collect()(0)

    val mean = globalStats.getAs[Double]("mean")
    val std = globalStats.getAs[Double]("std")



    // Calculate neighbor

    // Register IsNeighbor
    spark.udf.register("IsNeighbor", 
      (x1: Int, y1: Int, z1: Int, x2: Int, y2: Int, z2: Int) => 
        HotcellUtils.isNeighbor(x1, y1, z1, x2, y2, z2))


    // Calculate neighbor sums and counts
    val neighborInfo = spark.sql(
      s"""
      SELECT p1.x as x, p1.y as y, p1.z as z,
             SUM(p2.count) as neighborsum,
             COUNT(*) as neighborcount
      FROM pointcounts p1, pointcounts p2
      WHERE IsNeighbor(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z)
      GROUP BY p1.x, p1.y, p1.z
      """)
    neighborInfo.createOrReplaceTempView("neighborinfo")
    neighborInfo.show(10)



    // Calculate G* scores

    // Register calculateGScore
    spark.udf.register("GScore", 
      (x: Int, y: Int, z: Int, neighborSum: Double, neighborCount: Int) =>
        HotcellUtils.calculateGScore(x, y, z, mean, std, numCells, neighborCount, neighborSum))

    // Calculate G* scores
    val gScores = spark.sql(
      """
      SELECT x, y, z,
             GScore(x, y, z, neighborsum, neighborcount) as g_score
      FROM neighborinfo
      """)
    gScores.createOrReplaceTempView("gscores")
    gScores.show(10)

    // ordered by g_score, without showing g_score in the reault
    val result = spark.sql(
      """
      SELECT x, y, z
      FROM gscores
      ORDER BY g_score DESC
      LIMIT 50
      """)
    result.show(10)
  
    return result
  }

}