package cse512

object HotzoneUtils {

  def ST_Contains(queryRectangle: String, pointString: String): Boolean = {
    // get (x1, y1), (x2, y2) from queryRectangle
    val rectArray = queryRectangle.split(",")
    val xMin = rectArray(0).trim.toDouble
    val yMin = rectArray(1).trim.toDouble
    val xMax = rectArray(2).trim.toDouble
    val yMax = rectArray(3).trim.toDouble


    // get (x, y) from pointString
    val pointArray = pointString.split(",")
    val x = pointArray(0).trim.toDouble
    val y = pointArray(1).trim.toDouble

    // check if (x, y) is in the rectangle
    return x >= xMin && x <= xMax && y >= yMin && y <= yMax
  }

}